# Scott Hong
# GOVT 653

#Libraries Used
library(dplyr)
library(ggplot2)
library(plotly)
library(shiny)
library(tidyverse)
library(rstanarm)

#Reading formatted CSV file
base_df <- read.csv("...\\ANES_2020_Dataset.csv")

#Selecting columns of interest
base_df <- base_df %>%
  select(Race, Sex, Age, Income, Collgrad, Discrimination, Affect_W, Affect_H, Affect_B, Affect_A, Office_H, Office_B, Office_A, Ident_W, Ident_H, Ident_B, Ident_A, Work_W, Work_H, Work_B, Work_A)

#Excluding unneeded values and N/A row
base_df <- base_df[rowSums(base_df > -4) == ncol(base_df), ]
base_df <- na.omit(base_df)

#Summary of Dependent Variables
summary(base_df$Office_B)
summary(base_df$Office_H)
summary(base_df$Office_A)

#Table for Office Importance Variable
office_importance_black <- table(base_df$Office_B)
office_importance_hispanic <- table(base_df$Office_H) 
office_importance_asian <- table(base_df$Office_A)

#Barplots of Office Importance by Race
barplot(office_importance_black, main = "Frequency of Importance Scores for Blacks in Office", xlab = "Importance Score (1 Most Important 5 Not Important", ylab = "Frequency", col = "#524bd6")
barplot(office_importance_hispanic, main = "Frequency of Importance Scores for Hispanics in Office", xlab = "Importance Score (1 Most Important 5 Not Important", ylab = "Frequency", col = "#d14641")
barplot(office_importance_asian, main = "Frequency of Importance Scores for Asians in Office", xlab = "Importance Score (1 Most Important 5 Not Important", ylab = "Frequency", col = "#52ba6e")

#Subsets by race/ethnicity  
black_subset <- subset(base_df, Race == 2)
hispanic_subset <- subset(base_df, Race == 3)
asian_subset <- subset(base_df, Race == 4)

#Bayesian Linear Regression Model + Data Prediction + Linear Plot for Black Respondents
black_model <- stan_glm(Office_B ~ Ident_B+Age+Income+Collgrad+Discrimination, data = black_subset, refresh = 0)
print(black_model, digit = 2)
median(bayes_R2(black_model))

fake_black_data <- data.frame(Ident_B = seq(1, 5, 0.5), Age = mean(black_subset$Age), Income = mean(black_subset$Income), Collgrad = mean(black_subset$Collgrad), Discrimination = mean(black_subset$Discrimination))
pred_black <- predict(black_model, type = "response", newdata = fake_black_data)
sim_black <- posterior_linpred(black_model, newdata = fake_black_data)
black_lb <- apply(sim_black, 2, quantile, .025)
black_ub <- apply(sim_black, 2, quantile, .975)

black_plot <- ggplot(fake_black_data, aes(x = Ident_B, y = pred_black, ymin = black_lb, ymax = black_ub)) + 
  geom_ribbon(alpha = 0.4) + geom_line() + ggthemes::theme_clean() +
  labs(title = "Importance of Black Identity on Wanting More Blacks in Office", x = "Black Identity (1 Most Important 5 Not Important)", y = "More Blacks in Office (1 Most Important 5 Not Important)")

#Bayesian Linear Regression Model + Data Prediction + Linear Plot for Hispanic Respondents
hispanic_model <- stan_glm(Office_H ~ Ident_H+Age+Income+Collgrad+Discrimination, data = hispanic_subset, refresh = 0)
print(hispanic_model, digit = 2)
median(bayes_R2(hispanic_model))
  
fake_hispanic_data <- data.frame(Ident_H = seq(1, 5, 0.5), Age = mean(hispanic_subset$Age), Income = mean(hispanic_subset$Income), Collgrad = mean(hispanic_subset$Collgrad), Discrimination = mean(hispanic_subset$Discrimination))
pred_hispanic <- predict(hispanic_model, type = "response", newdata = fake_hispanic_data)
sim_hispanic <- posterior_linpred(hispanic_model, newdata = fake_hispanic_data)
hispanic_lb <- apply(sim_hispanic, 2, quantile, .025)
hispanic_ub <- apply(sim_hispanic, 2, quantile, .975)

hispanic_plot <- ggplot(fake_hispanic_data, aes(x = Ident_H, y = pred_hispanic, ymin = hispanic_lb, ymax = hispanic_ub)) + 
  geom_ribbon(alpha = 0.4) + geom_line() + ggthemes::theme_clean() +
  labs(title = "Importance of Hispanic Identity on Wanting More Hispanics in Office", x = "Hispanic Identity (1 Most Important 5 Not Important)", y = "More Hispanics in Office (1 Most Important 5 Not Important)")

#Bayesian Linear Regression Model + Data Prediction + Linear Plot for Asian Respondents
asian_model <- stan_glm(Office_A ~ Ident_A+Age+Income+Collgrad+Discrimination, data = asian_subset, refresh = 0)
print(asian_model, digit = 2)
median(bayes_R2(asian_model))

fake_asian_data <- data.frame(Ident_A = seq(1, 5, 0.5), Age = mean(asian_subset$Age), Income = mean(asian_subset$Income), Collgrad = mean(asian_subset$Collgrad), Discrimination = mean(asian_subset$Discrimination))
pred_asian <- predict(asian_model, type = "response", newdata = fake_asian_data)
sim_asian <- posterior_linpred(asian_model, newdata = fake_asian_data)
asian_lb <- apply(sim_asian, 2, quantile, .025)
asian_ub <- apply(sim_asian, 2, quantile, .975)

asian_plot <- ggplot(fake_asian_data, aes(x = Ident_A, y = pred_asian, ymin = asian_lb, ymax = asian_ub)) + 
  geom_ribbon(alpha = 0.4) + geom_line() + ggthemes::theme_clean() +
  labs(title = "Importance of Asian Identity on Wanting More Asians in Office", x = "Asian Identity (1 Most Important 5 Not Important)", y = "More Asian in Office (1 Most Important 5 Not Important)")